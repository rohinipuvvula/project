$(window).load("on",function(){
    $("#preloader").fadeOut();
})
